"""
flight_app.py
Flight Aerodynamic Coefficient Predictor — GUI

Run with:  python flight_app.py
Requires:  flight_core.py in the same folder.

Optional dependencies (the app degrades gracefully if missing):
  - lightgbm   -> LightGBM tab disabled if not installed
  - tensorflow -> DNN tab disabled if not installed
  - Pillow     -> plot images can't be shown inline if missing (still saved to disk)
"""

import os
import time
import threading
import queue
import traceback
from datetime import datetime

import numpy as np
import pandas as pd

import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext

try:
    from PIL import Image, ImageTk
    HAS_PIL = True
except ImportError:
    HAS_PIL = False

import flight_core as fc

APP_BG = "#f4f6f8"
ACCENT = "#1f6feb"
CARD_BG = "#ffffff"
TEXT_MUTED = "#6b7280"
GOOD = "#0f9d58"
BAD = "#d93025"
WARN = "#e8710a"

FONT_TITLE = ("Segoe UI", 13, "bold")
FONT_SUB = ("Segoe UI", 9)
FONT_MONO = ("Consolas", 9)


# ======================================================================
# Small reusable widgets
# ======================================================================

class ScrollableFrame(ttk.Frame):
    """A frame with cross-platform mouse-wheel scrolling (vertical), whose inner
    content is width-synced to the visible canvas so it resizes properly when
    the window is resized or snapped to half-screen.

    Mouse-wheel routing is handled centrally by FlightApp._on_global_mousewheel
    (bound once, application-wide) rather than by each instance grabbing and
    releasing a global binding on hover. The previous per-instance bind_all()/
    <Enter>/<Leave> approach is what caused scrolling to 'get stuck': with
    several ScrollableFrames nested inside each other (e.g. the input/output
    feature lists sitting inside the tab's outer scroll area), each one fought
    over the same single global binding, and Tk's Enter/Leave events for
    deeply nested canvases don't fire reliably enough to hand that binding
    back and forth correctly. A single dispatcher that walks up from whatever
    widget is directly under the cursor to the nearest enclosing scrollable
    canvas has no such handoff to get stuck on.
    """

    def __init__(self, parent, height=350, **kwargs):
        super().__init__(parent, **kwargs)
        self.canvas = tk.Canvas(self, height=height, highlightthickness=0, bg=CARD_BG)
        self.canvas.scrollable_owner = self  # marker used by the app-wide wheel dispatcher
        scrollbar = ttk.Scrollbar(self, orient="vertical", command=self.canvas.yview)
        self.inner = ttk.Frame(self.canvas)

        self._inner_window = self.canvas.create_window((0, 0), window=self.inner, anchor="nw")
        self.inner.bind("<Configure>", lambda e: self.canvas.configure(scrollregion=self.canvas.bbox("all")))
        self.canvas.bind("<Configure>", self._on_canvas_configure)
        self.canvas.configure(yscrollcommand=scrollbar.set)

        self.canvas.pack(side="left", fill="both", expand=True)
        scrollbar.pack(side="right", fill="y")

    def _on_canvas_configure(self, event):
        # Keep the inner frame exactly as wide as the visible canvas so content
        # (cards, entries, plots) reflows correctly on any window size, including
        # half-screen / split-screen snapping.
        self.canvas.itemconfig(self._inner_window, width=event.width)

    def scroll(self, units):
        self.canvas.yview_scroll(units, "units")


class ToolTip:
    """Simple hover tooltip. Attach to any widget with ToolTip(widget, 'text')."""

    def __init__(self, widget, text, wraplength=320):
        self.widget = widget
        self.text = text
        self.wraplength = wraplength
        self.tip = None
        widget.bind("<Enter>", self._show)
        widget.bind("<Leave>", self._hide)

    def _show(self, event=None):
        if self.tip is not None or not self.text:
            return
        x = self.widget.winfo_rootx() + 18
        y = self.widget.winfo_rooty() + self.widget.winfo_height() + 6
        self.tip = tk.Toplevel(self.widget)
        self.tip.wm_overrideredirect(True)
        self.tip.wm_geometry(f"+{x}+{y}")
        lbl = tk.Label(self.tip, text=self.text, justify="left", background="#2b2b2b", fg="white",
                        relief="solid", borderwidth=1, padx=8, pady=5, wraplength=self.wraplength,
                        font=("Segoe UI", 8))
        lbl.pack()

    def _hide(self, event=None):
        if self.tip is not None:
            self.tip.destroy()
            self.tip = None


class Card(ttk.Frame):
    """A padded, titled 'card' section to keep the UI organized instead of congested."""

    def __init__(self, parent, title=None, **kwargs):
        super().__init__(parent, style="Card.TFrame", padding=12, **kwargs)
        if title:
            ttk.Label(self, text=title, font=FONT_TITLE, background=CARD_BG).pack(anchor="w", pady=(0, 8))


class PlotViewer(ttk.Frame):
    """A dropdown + responsive image preview + 'Open in New Window' button.
    Re-renders the image whenever the panel is resized, so plots stay visible
    at any window size (fixes the 'plots too small / not visible' complaint)."""

    def __init__(self, parent, **kwargs):
        super().__init__(parent, style="Card.TFrame", **kwargs)
        self.plots = {}   # name -> path
        self.combo_var = tk.StringVar()

        top = ttk.Frame(self, style="Card.TFrame")
        top.pack(fill="x")
        ttk.Label(top, text="Plot:", background=CARD_BG).pack(side="left")
        self.combo = ttk.Combobox(top, textvariable=self.combo_var, state="readonly", width=42)
        self.combo.pack(side="left", padx=6)
        self.combo.bind("<<ComboboxSelected>>", lambda e: self._render())
        ttk.Button(top, text="Open in New Window", command=self._open_full_size).pack(side="left", padx=6)

        self.img_label = ttk.Label(self, anchor="center", background=CARD_BG)
        self.img_label.pack(fill="both", expand=True, pady=8)
        self._photo_ref = None
        self.img_label.bind("<Configure>", lambda e: self._render())

        if not HAS_PIL:
            self.img_label.config(
                text="Install Pillow to preview plots here (pip install pillow).\n"
                     "Plots are still saved to your output folder.", foreground=BAD)

    def add_plot(self, name, path):
        self.plots[name] = path
        self.combo["values"] = list(self.plots.keys())
        if not self.combo_var.get():
            self.combo.current(0)
        self._render()

    def clear(self):
        self.plots = {}
        self.combo["values"] = []
        self.combo_var.set("")
        self.img_label.config(image="", text="")
        self._photo_ref = None

    def _render(self):
        if not HAS_PIL:
            return
        name = self.combo_var.get()
        path = self.plots.get(name)
        if not path or not os.path.exists(path):
            return
        w = max(self.img_label.winfo_width(), 400)
        h = max(self.img_label.winfo_height(), 300)
        try:
            img = Image.open(path)
            try:
                resample = Image.Resampling.LANCZOS
            except AttributeError:
                resample = Image.ANTIALIAS
            img.thumbnail((max(w - 20, 100), max(h - 20, 100)), resample)
            photo = ImageTk.PhotoImage(img)
            self.img_label.config(image=photo, text="")
            self._photo_ref = photo  # keep a reference so it isn't garbage-collected
        except Exception as e:
            self.img_label.config(text=f"Failed to display plot:\n{e}", image="")

    def _open_full_size(self):
        if not HAS_PIL:
            messagebox.showinfo("Pillow required", "Install Pillow (pip install pillow) to preview plots.")
            return
        name = self.combo_var.get()
        path = self.plots.get(name)
        if not path or not os.path.exists(path):
            messagebox.showinfo("No plot", "Generate a plot first.")
            return
        top = tk.Toplevel(self)
        top.title(name)
        top.geometry("1000x750")
        lbl = ttk.Label(top, anchor="center")
        lbl.pack(fill="both", expand=True)

        def render_full(event=None):
            try:
                img = Image.open(path)
                w = max(top.winfo_width(), 400)
                h = max(top.winfo_height(), 300)
                try:
                    resample = Image.Resampling.LANCZOS
                except AttributeError:
                    resample = Image.ANTIALIAS
                img2 = img.copy()
                img2.thumbnail((w - 20, h - 20), resample)
                photo = ImageTk.PhotoImage(img2)
                lbl.config(image=photo)
                lbl.image = photo
            except Exception as e:
                lbl.config(text=f"Failed to display plot:\n{e}")

        top.bind("<Configure>", render_full)
        top.after(50, render_full)


def build_param_panel(parent, specs, optional=True):
    """Builds a grid of labeled hyperparameter inputs from a param-spec list, each
    with a tooltip explaining it. If optional=True, every row gets a 'Use' checkbox;
    the value is only sent to the model if that box is checked (unchecked = the
    library's own default is used, and the value field is disabled/greyed out so
    it's visually clear it isn't taking effect). If optional=False (DNN), every
    field is always active since a DNN has no external 'library default'.
    Returns dict[key] -> (enable_var_or_None, value_var, kind).
    """
    frame = ttk.Frame(parent, style="Card.TFrame")
    varmap = {}
    for i, (key, kind, default, choices) in enumerate(specs):
        r, c = divmod(i, 2)
        cell = ttk.Frame(frame, style="Card.TFrame")
        cell.grid(row=r, column=c, sticky="w", padx=(4, 18), pady=4)

        enable_var = None
        if optional:
            enable_var = tk.BooleanVar(value=False)
            cb = ttk.Checkbutton(cell, variable=enable_var)
            cb.pack(side="left")

        label_text = key.replace("_", " ")
        lbl = ttk.Label(cell, text=label_text, width=20, anchor="w", background=CARD_BG,
                         font=("Segoe UI", 9))
        lbl.pack(side="left")
        help_icon = ttk.Label(cell, text=" (?) ", foreground=ACCENT, background=CARD_BG,
                               font=("Segoe UI", 8, "bold"), cursor="question_arrow")
        help_icon.pack(side="left")
        ToolTip(help_icon, fc.PARAM_HELP.get(key, "No description available."))

        if kind == "choice":
            var = tk.StringVar(value=str(default))
            widget = ttk.Combobox(cell, textvariable=var, values=choices, width=13, state="readonly")
        elif kind == "bool":
            var = tk.BooleanVar(value=bool(default))
            widget = ttk.Checkbutton(cell, variable=var)
        else:
            var = tk.StringVar(value=str(default))
            widget = ttk.Entry(cell, textvariable=var, width=14)
        widget.pack(side="left", padx=(4, 0))

        if optional:
            def _toggle(w=widget, ev=enable_var, k=kind):
                if k == "choice":
                    w.config(state="readonly" if ev.get() else "disabled")
                else:
                    w.config(state="normal" if ev.get() else "disabled")
            enable_var.trace_add("write", lambda *a, f=_toggle: f())
            _toggle()

        varmap[key] = (enable_var, var, kind)
    return frame, varmap


def read_param_panel(varmap, specs, optional=True):
    """Casts tk values back to python types. If optional=True, only params whose
    'Use' checkbox is checked are included — everything else is omitted so the
    underlying library falls back to its own default."""
    out = {}
    for key, kind, default, choices in specs:
        enable_var, var, vkind = varmap[key]
        if optional and (enable_var is None or not enable_var.get()):
            continue
        raw = var.get()
        try:
            if kind == "int":
                out[key] = int(float(raw))
            elif kind == "float":
                out[key] = float(raw)
            elif kind == "bool":
                out[key] = bool(raw)
            else:
                out[key] = raw
        except (ValueError, TypeError):
            out[key] = default
    return out


# ======================================================================
# Main application
# ======================================================================

class FlightApp(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Flight Aerodynamic Coefficient Predictor")
        self.geometry("1280x860")
        self.minsize(900, 600)
        self.configure(bg=APP_BG)
        self._init_style()

        # ---- state ----
        self.training_path = None
        self.training_sheets = []
        self.data_mode = tk.StringVar(value="single")   # 'single' or 'dual'
        self.single_sheet_var = tk.StringVar()
        self.input_sheet_var = tk.StringVar()
        self.output_sheet_var = tk.StringVar()

        self.input_col_vars = {}       # col -> BooleanVar
        self.input_col_widgets = {}    # col -> Checkbutton (for fast filtering)
        self.output_col_vars = {}
        self.output_col_widgets = {}
        self.mach_range_text = tk.StringVar(value="MACH range: —")

        self.output_dir = os.getcwd()
        self.model_checks = {}       # algo_name -> BooleanVar ("train this model?")
        self.scaling_checks = {}     # algo_name -> BooleanVar ("scale inputs/outputs before training?")
        self.SCALING_CAPABLE_ALGOS = ("XGBoost", "RandomForest", "LightGBM")
        self.param_varmaps = {}      # algo_name -> varmap
        self.trained_models = {}     # display_name -> model_data
        self.active_model_name = tk.StringVar(value="")

        self.plot_title_train = tk.StringVar(value="Training Run")
        self.plot_title_predict = tk.StringVar(value="Prediction Run")

        self.test_path = None
        self.test_sheets = []
        self.test_data_mode = tk.StringVar(value="single")
        self.test_single_sheet_var = tk.StringVar()
        self.test_input_sheet_var = tk.StringVar()
        self.test_output_sheet_var = tk.StringVar()
        self.test_df_in = None
        self.test_df_out = None

        self.override_enabled = tk.BooleanVar(value=False)
        self.override_col_var = tk.StringVar()
        self.override_values_var = tk.StringVar()

        self.manual_entry_vars = {}      # col -> StringVar (current form)
        self.manual_results = []         # list of dict, accumulated batch results

        self.msg_queue = queue.Queue()
        self.stop_flag = threading.Event()

        self._build_ui()
        self.after(100, self._poll_queue)

        # Single, application-wide mouse-wheel dispatcher (see ScrollableFrame's
        # docstring for why this replaces per-instance bind_all handoffs).
        self.bind_all("<MouseWheel>", self._on_global_mousewheel)
        self.bind_all("<Button-4>", self._on_global_mousewheel)
        self.bind_all("<Button-5>", self._on_global_mousewheel)

    def _on_global_mousewheel(self, event):
        """Routes a wheel event to the nearest enclosing ScrollableFrame, found
        by walking up the widget tree from whatever is directly under the
        cursor. This naturally handles nested scrollable regions (e.g. the
        input/output feature lists inside the tab's outer scroll area) — the
        innermost one under the pointer always wins, with no handoff state
        that can get stuck.
        Treeviews (the manual-entry results table) are left alone entirely so
        their own native scrolling isn't double-handled."""
        widget = event.widget
        if isinstance(widget, ttk.Treeview):
            return
        w = widget
        steps = 0
        while w is not None and steps < 50:
            owner = getattr(w, "scrollable_owner", None)
            if owner is not None:
                if hasattr(event, "num") and event.num == 4:
                    owner.scroll(-1)
                elif hasattr(event, "num") and event.num == 5:
                    owner.scroll(1)
                elif hasattr(event, "delta") and event.delta != 0:
                    owner.scroll(-1 if event.delta > 0 else 1)
                return
            w = getattr(w, "master", None)
            steps += 1

    # ------------------------------------------------------------------
    def _init_style(self):
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass
        style.configure(".", background=APP_BG, font=FONT_SUB)
        style.configure("TFrame", background=APP_BG)
        style.configure("Card.TFrame", background=CARD_BG, relief="flat")
        style.configure("TLabel", background=APP_BG)
        style.configure("TNotebook", background=APP_BG, tabmargins=(6, 6, 6, 0))
        style.configure("TNotebook.Tab", font=("Segoe UI", 10, "bold"), padding=(16, 8))
        style.configure("Accent.TButton", font=("Segoe UI", 9, "bold"))
        style.configure("TButton", padding=6)
        style.configure("Treeview", font=("Consolas", 9), rowheight=22)
        style.configure("Treeview.Heading", font=("Segoe UI", 9, "bold"))

    # ------------------------------------------------------------------
    def _build_ui(self):
        header = ttk.Frame(self)
        header.pack(fill="x", padx=14, pady=(12, 0))
        ttk.Label(header, text="Flight Aerodynamic Coefficient Predictor",
                  font=("Segoe UI", 16, "bold")).pack(side="left")
        ttk.Label(header, text="  XGBoost · Random Forest · SVR · LightGBM · DNN",
                  foreground=TEXT_MUTED).pack(side="left", padx=(8, 0))

        nb = ttk.Notebook(self)
        nb.pack(fill="both", expand=True, padx=10, pady=10)

        self.tab_data = ttk.Frame(nb)
        self.tab_train = ttk.Frame(nb)
        self.tab_predict = ttk.Frame(nb)

        nb.add(self.tab_data, text="1 · Data & Features")
        nb.add(self.tab_train, text="2 · Train Model")
        nb.add(self.tab_predict, text="3 · Predict")

        self._build_tab_data()
        self._build_tab_train()
        self._build_tab_predict()

    # ==================================================================
    # TAB 1 — DATA & FEATURES
    # ==================================================================
    def _build_tab_data(self):
        self.tab_data.rowconfigure(0, weight=1)
        self.tab_data.columnconfigure(0, weight=1)
        outer = ScrollableFrame(self.tab_data, height=700)
        outer.grid(row=0, column=0, sticky="nsew")
        root = outer.inner

        card1 = Card(root, title="Training Dataset")
        card1.pack(fill="x", padx=10, pady=8)

        row1 = ttk.Frame(card1, style="Card.TFrame")
        row1.pack(fill="x")
        ttk.Button(row1, text="Browse Training File (.xlsx)", command=self._browse_training_file).pack(side="left")
        ttk.Button(row1, text="Remove File", command=self._remove_training_file).pack(side="left", padx=6)
        self.lbl_train_path = ttk.Label(row1, text="No file loaded", foreground=TEXT_MUTED, background=CARD_BG)
        self.lbl_train_path.pack(side="left", padx=12)

        row2 = ttk.Frame(card1, style="Card.TFrame")
        row2.pack(fill="x", pady=(10, 0))
        ttk.Label(row2, text="Sheet layout:", background=CARD_BG).pack(side="left")
        ttk.Radiobutton(row2, text="Inputs + outputs in the same sheet", variable=self.data_mode,
                         value="single", command=self._on_data_mode_change).pack(side="left", padx=10)
        ttk.Radiobutton(row2, text="Inputs and outputs in different sheets", variable=self.data_mode,
                         value="dual", command=self._on_data_mode_change).pack(side="left", padx=10)

        self.sheet_picker_frame = ttk.Frame(card1, style="Card.TFrame")
        self.sheet_picker_frame.pack(fill="x", pady=(8, 0))

        self.lbl_mach = ttk.Label(card1, textvariable=self.mach_range_text, foreground=ACCENT,
                                   background=CARD_BG, font=("Segoe UI", 9, "bold"))
        self.lbl_mach.pack(anchor="w", pady=(8, 0))

        card2 = Card(root, title="Choose Input Features and Output Coefficients")
        card2.pack(fill="both", expand=True, padx=10, pady=8)

        filt_row = ttk.Frame(card2, style="Card.TFrame")
        filt_row.pack(fill="x")
        ttk.Label(filt_row, text="Filter columns:", background=CARD_BG).pack(side="left")
        self.filter_var = tk.StringVar()
        self.filter_var.trace_add("write", lambda *a: self._apply_filter())
        ttk.Entry(filt_row, textvariable=self.filter_var, width=28).pack(side="left", padx=6)

        cols_frame = ttk.Frame(card2, style="Card.TFrame")
        cols_frame.pack(fill="both", expand=True, pady=(8, 0))
        cols_frame.columnconfigure(0, weight=1)
        cols_frame.columnconfigure(1, weight=1)
        cols_frame.rowconfigure(0, weight=1)

        left = ttk.Frame(cols_frame, style="Card.TFrame")
        left.grid(row=0, column=0, sticky="nsew", padx=(0, 8))
        right = ttk.Frame(cols_frame, style="Card.TFrame")
        right.grid(row=0, column=1, sticky="nsew", padx=(8, 0))

        lrow = ttk.Frame(left, style="Card.TFrame")
        lrow.pack(fill="x")
        ttk.Label(lrow, text="Input Features", font=("Segoe UI", 10, "bold"), background=CARD_BG).pack(side="left")
        ttk.Button(lrow, text="All", width=4, command=lambda: self._set_all(self.input_col_vars, True)).pack(side="right")
        ttk.Button(lrow, text="None", width=5, command=lambda: self._set_all(self.input_col_vars, False)).pack(side="right", padx=4)
        self.input_scroll = ScrollableFrame(left, height=340)
        self.input_scroll.pack(fill="both", expand=True, pady=6)

        rrow = ttk.Frame(right, style="Card.TFrame")
        rrow.pack(fill="x")
        ttk.Label(rrow, text="Output Coefficients", font=("Segoe UI", 10, "bold"), background=CARD_BG).pack(side="left")
        ttk.Button(rrow, text="All", width=4, command=lambda: self._set_all(self.output_col_vars, True)).pack(side="right")
        ttk.Button(rrow, text="None", width=5, command=lambda: self._set_all(self.output_col_vars, False)).pack(side="right", padx=4)
        self.output_scroll = ScrollableFrame(right, height=340)
        self.output_scroll.pack(fill="both", expand=True, pady=6)

        self.lbl_selection_summary = ttk.Label(card2, text="0 inputs, 0 outputs selected",
                                                 foreground=ACCENT, background=CARD_BG,
                                                 font=("Segoe UI", 9, "bold"))
        self.lbl_selection_summary.pack(anchor="w", pady=(6, 0))

        self._on_data_mode_change()

    def _on_data_mode_change(self):
        """Rebuild the sheet picker for the newly-selected mode AND reload the
        column checklists — this second step was missing before, which is why
        switching between 'same sheet' / 'different sheets' silently left the
        output-coefficient list showing stale data."""
        for w in self.sheet_picker_frame.winfo_children():
            w.destroy()
        if self.data_mode.get() == "single":
            ttk.Label(self.sheet_picker_frame, text="Sheet:", background=CARD_BG).pack(side="left")
            cb = ttk.Combobox(self.sheet_picker_frame, textvariable=self.single_sheet_var,
                               values=self.training_sheets, width=24, state="readonly")
            cb.pack(side="left", padx=6)
            cb.bind("<<ComboboxSelected>>", lambda e: self._reload_columns_for_current_mode())
        else:
            ttk.Label(self.sheet_picker_frame, text="Input sheet:", background=CARD_BG).pack(side="left")
            cb1 = ttk.Combobox(self.sheet_picker_frame, textvariable=self.input_sheet_var,
                                values=self.training_sheets, width=20, state="readonly")
            cb1.pack(side="left", padx=6)
            ttk.Label(self.sheet_picker_frame, text="Output sheet:", background=CARD_BG).pack(side="left", padx=(12, 0))
            cb2 = ttk.Combobox(self.sheet_picker_frame, textvariable=self.output_sheet_var,
                                values=self.training_sheets, width=20, state="readonly")
            cb2.pack(side="left", padx=6)
            cb1.bind("<<ComboboxSelected>>", lambda e: self._reload_columns_for_current_mode())
            cb2.bind("<<ComboboxSelected>>", lambda e: self._reload_columns_for_current_mode())

        self._reload_columns_for_current_mode()

    def _browse_training_file(self):
        path = filedialog.askopenfilename(
            title="Select training Excel file",
            filetypes=[("Excel files", "*.xlsx *.xls *.xlsm")])
        if not path:
            return
        ext = os.path.splitext(path)[1].lower()
        if ext not in (".xlsx", ".xls", ".xlsm"):
            messagebox.showerror("Invalid file", "Please upload an Excel file only (.xlsx, .xls, .xlsm).")
            return
        try:
            sheets = fc.list_sheet_names(path)
        except Exception as e:
            messagebox.showerror("Error", f"Could not open workbook:\n{e}")
            return

        self.training_path = path
        self.training_sheets = sheets
        self.lbl_train_path.config(text=os.path.basename(path), foreground="black")

        if sheets:
            self.single_sheet_var.set(sheets[0])
            self.input_sheet_var.set(sheets[0])
            self.output_sheet_var.set(sheets[1] if len(sheets) > 1 else sheets[0])

        self._on_data_mode_change()

    def _remove_training_file(self):
        self.training_path = None
        self.training_sheets = []
        self.single_sheet_var.set("")
        self.input_sheet_var.set("")
        self.output_sheet_var.set("")
        self.lbl_train_path.config(text="No file loaded", foreground=TEXT_MUTED)
        self.mach_range_text.set("MACH range: —")
        for w in self.input_scroll.inner.winfo_children():
            w.destroy()
        for w in self.output_scroll.inner.winfo_children():
            w.destroy()
        self.input_col_vars.clear()
        self.input_col_widgets.clear()
        self.output_col_vars.clear()
        self.output_col_widgets.clear()
        self._update_selection_summary()
        self._on_data_mode_change()

    def _reload_columns_for_current_mode(self):
        if not self.training_path:
            return
        try:
            if self.data_mode.get() == "single":
                sheet = self.single_sheet_var.get()
                if not sheet:
                    return
                cols = fc.read_sheet_columns(self.training_path, sheet)
                in_cols, out_cols = cols, cols
            else:
                in_sheet, out_sheet = self.input_sheet_var.get(), self.output_sheet_var.get()
                if not in_sheet or not out_sheet:
                    return
                in_cols = fc.read_sheet_columns(self.training_path, in_sheet)
                out_cols = fc.read_sheet_columns(self.training_path, out_sheet)
        except Exception as e:
            messagebox.showerror("Error", f"Could not read columns:\n{e}")
            return

        self._populate_column_checklist(self.input_scroll.inner, self.input_col_vars,
                                         self.input_col_widgets, in_cols, is_input=True)
        self._populate_column_checklist(self.output_scroll.inner, self.output_col_vars,
                                         self.output_col_widgets, out_cols, is_input=False)
        self._update_mach_range()
        self._update_selection_summary()

    def _populate_column_checklist(self, parent, varstore, widgetstore, cols, is_input):
        for w in parent.winfo_children():
            w.destroy()
        varstore.clear()
        widgetstore.clear()
        default_outputs = {"CN", "CS", "CAF", "CPM", "CYM", "CRM"}
        for i, col in enumerate(cols):
            default_val = (col not in default_outputs) if is_input else (col in default_outputs)
            var = tk.BooleanVar(value=default_val)
            var.trace_add("write", lambda *a: self._update_selection_summary())
            cb = ttk.Checkbutton(parent, text=col, variable=var)
            cb.grid(row=i, column=0, sticky="w", padx=6, pady=1)
            varstore[col] = var
            widgetstore[col] = cb

    def _apply_filter(self):
        needle = self.filter_var.get().strip().lower()
        for widgetstore in (self.input_col_widgets, self.output_col_widgets):
            for col, cb in widgetstore.items():
                if needle in col.lower():
                    cb.grid()
                else:
                    cb.grid_remove()

    def _set_all(self, varstore, value):
        needle = self.filter_var.get().strip().lower()
        for col, var in varstore.items():
            if needle in col.lower():
                var.set(value)
        self._update_selection_summary()

    def _update_selection_summary(self):
        n_in = sum(v.get() for v in self.input_col_vars.values())
        n_out = sum(v.get() for v in self.output_col_vars.values())
        self.lbl_selection_summary.config(text=f"{n_in} input features, {n_out} output coefficients selected")

    def _update_mach_range(self):
        if not self.training_path:
            return
        try:
            if self.data_mode.get() == "single":
                df = pd.read_excel(self.training_path, sheet_name=self.single_sheet_var.get())
            else:
                df = pd.read_excel(self.training_path, sheet_name=self.input_sheet_var.get())
            rng = fc.get_mach_range(df)
            if rng:
                self.mach_range_text.set(f"MACH range in dataset: {rng[0]:.4f} — {rng[1]:.4f}")
            else:
                self.mach_range_text.set("MACH range: no MACH column found")
        except Exception:
            self.mach_range_text.set("MACH range: could not compute")

    def get_selected_inputs(self):
        return [c for c, v in self.input_col_vars.items() if v.get()]

    def get_selected_outputs(self):
        return [c for c, v in self.output_col_vars.items() if v.get()]

    # ==================================================================
    # TAB 2 — TRAIN MODEL
    # ==================================================================
    def _build_tab_train(self):
        self.tab_train.rowconfigure(0, weight=1)
        self.tab_train.columnconfigure(0, weight=1)
        outer = ScrollableFrame(self.tab_train, height=700)
        outer.grid(row=0, column=0, sticky="nsew")
        root = outer.inner

        card_out = Card(root, title="Output Folder")
        card_out.pack(fill="x", padx=10, pady=8)
        row = ttk.Frame(card_out, style="Card.TFrame")
        row.pack(fill="x")
        ttk.Button(row, text="Choose Output Folder", command=self._choose_output_dir).pack(side="left")
        self.lbl_out_dir = ttk.Label(row, text=self.output_dir, foreground=TEXT_MUTED, background=CARD_BG)
        self.lbl_out_dir.pack(side="left", padx=10)

        card_models = Card(root, title="Models to Train  (check a model to train it — hover the (?) next to any "
                                        "field for what it does; leave a field's checkbox unticked to use that "
                                        "library's own default for it)")
        card_models.pack(fill="both", expand=True, padx=10, pady=8)

        nb = ttk.Notebook(card_models)
        nb.pack(fill="both", expand=True)

        for algo_name, specs in fc.MODEL_SPECS.items():
            tab = ttk.Frame(nb, style="Card.TFrame", padding=10)
            available = True
            note = ""
            if algo_name == "LightGBM" and not fc.HAS_LGB:
                available = False
                note = "LightGBM is not installed in this environment."
            if algo_name == "DNN" and not fc.HAS_TF:
                available = False
                note = "TensorFlow is not installed in this environment."

            var = tk.BooleanVar(value=False)
            self.model_checks[algo_name] = var
            head = ttk.Frame(tab, style="Card.TFrame")
            head.pack(fill="x")
            cb = ttk.Checkbutton(head, text=f"Train {algo_name}", variable=var)
            cb.pack(side="left")
            if not available:
                cb.config(state="disabled")
                ttk.Label(head, text=note, foreground=BAD, background=CARD_BG).pack(side="left", padx=10)

            if algo_name in self.SCALING_CAPABLE_ALGOS:
                scale_var = tk.BooleanVar(value=False)
                self.scaling_checks[algo_name] = scale_var
                scale_row = ttk.Frame(tab, style="Card.TFrame")
                scale_row.pack(fill="x", pady=(6, 0))
                scale_cb = ttk.Checkbutton(
                    scale_row, text="Scale inputs and outputs before training (StandardScaler)",
                    variable=scale_var)
                scale_cb.pack(side="left")
                scale_help = ttk.Label(scale_row, text=" (?) ", foreground=ACCENT, background=CARD_BG,
                                        font=("Segoe UI", 8, "bold"), cursor="question_arrow")
                scale_help.pack(side="left")
                ToolTip(scale_help,
                        f"{algo_name} doesn't strictly need scaled inputs to be accurate (tree splits don't "
                        "care about feature magnitude), but scaling can still help numerical stability when "
                        "features have very different ranges. If enabled, the scaler is trained alongside the "
                        "model, saved with it, and applied automatically every time you predict — you'll always "
                        "get predictions back in real units either way, this only affects what the model sees "
                        "internally. If you're not sure, leave this unchecked; it's off by default.")
                if not available:
                    scale_cb.config(state="disabled")

            optional = fc.MODEL_SUPPORTS_OPTIONAL_PARAMS.get(algo_name, True)
            panel, varmap = build_param_panel(tab, specs, optional=optional)
            panel.pack(fill="x", pady=(10, 0))
            self.param_varmaps[algo_name] = varmap

            nb.add(tab, text=algo_name)

        card_actions = Card(root, title="Train / Save / Load")
        card_actions.pack(fill="x", padx=10, pady=8)
        arow = ttk.Frame(card_actions, style="Card.TFrame")
        arow.pack(fill="x")

        self.btn_train = ttk.Button(arow, text="Train Model(s)", style="Accent.TButton", command=self._start_training)
        self.btn_train.pack(side="left")
        self.btn_stop = ttk.Button(arow, text="Stop Training", command=self._stop_training, state="disabled")
        self.btn_stop.pack(side="left", padx=6)

        ttk.Label(arow, text="Active model:", background=CARD_BG).pack(side="left", padx=(20, 4))
        self.active_model_combo = ttk.Combobox(arow, textvariable=self.active_model_name, values=[],
                                                width=20, state="readonly")
        self.active_model_combo.pack(side="left")
        self.active_model_combo.bind("<<ComboboxSelected>>", lambda e: self._sync_predict_tab_with_model())

        # A second row for save/load/clear — keeping these on their own row
        # (rather than crammed onto the row above) means they stay visible
        # and clickable instead of getting clipped when the window is narrow.
        arow2 = ttk.Frame(card_actions, style="Card.TFrame")
        arow2.pack(fill="x", pady=(8, 0))
        ttk.Button(arow2, text="Save Model", command=self._save_active_model).pack(side="left")
        ttk.Button(arow2, text="Load Model", command=self._load_model_dialog).pack(side="left", padx=6)
        ttk.Button(arow2, text="Clear Trained Model(s)", command=self._clear_trained_models).pack(side="left", padx=6)
        ttk.Button(arow2, text="Clear Loaded Model", command=self._clear_loaded_model).pack(side="left", padx=6)

        self.progress = ttk.Progressbar(card_actions, mode="indeterminate")
        self.progress.pack(fill="x", pady=(10, 0))

        # ---- Results: Log (with metrics) / Plots as full-width sub-tabs ----
        card_results = Card(root, title="Results")
        card_results.pack(fill="both", expand=True, padx=10, pady=8)
        card_results.configure(height=520)

        title_row = ttk.Frame(card_results, style="Card.TFrame")
        title_row.pack(fill="x")
        ttk.Label(title_row, text="Plot title:", background=CARD_BG).pack(side="left")
        ttk.Entry(title_row, textvariable=self.plot_title_train, width=40).pack(side="left", padx=6)
        btn_regen = ttk.Button(title_row, text="Apply Title to Plots", command=self._regenerate_train_plots)
        btn_regen.pack(side="left", padx=6)
        ToolTip(btn_regen,
                "Edit the 'Plot title' box above, then click this to redraw the active model's plots with the "
                "new title (using the same trained model — this doesn't retrain or change any data). If you "
                "click it without changing the title, the plots will look identical, since nothing else changed.")
        self.lbl_regen_status = ttk.Label(title_row, text="", foreground=GOOD, background=CARD_BG)
        self.lbl_regen_status.pack(side="left", padx=6)
        ttk.Button(title_row, text="Clear Log", command=lambda: self.log_box.delete("1.0", tk.END)).pack(side="right")
        ttk.Button(title_row, text="Clear Plots", command=lambda: self.train_plot_viewer.clear()).pack(side="right", padx=(0, 6))

        results_nb = ttk.Notebook(card_results)
        results_nb.pack(fill="both", expand=True, pady=(8, 0))

        log_tab = ttk.Frame(results_nb, style="Card.TFrame", padding=8)
        results_nb.add(log_tab, text="Log & Metrics")
        self.log_box = scrolledtext.ScrolledText(log_tab, height=26, font=FONT_MONO, wrap="word")
        self.log_box.pack(fill="both", expand=True)

        plots_tab = ttk.Frame(results_nb, style="Card.TFrame", padding=8)
        results_nb.add(plots_tab, text="Plots")
        self.train_plot_viewer = PlotViewer(plots_tab)
        self.train_plot_viewer.pack(fill="both", expand=True)

    def _choose_output_dir(self):
        d = filedialog.askdirectory()
        if d:
            self.output_dir = d
            self.lbl_out_dir.config(text=d, foreground="black")

    def _log(self, msg):
        self.msg_queue.put(("log", str(msg)))

    def _start_training(self):
        if not self.training_path:
            messagebox.showwarning("No file", "Load a training file on Tab 1 first.")
            return
        input_cols = self.get_selected_inputs()
        output_cols = self.get_selected_outputs()
        if not input_cols:
            messagebox.showwarning("No inputs", "Select at least one input feature on Tab 1.")
            return
        if not output_cols:
            messagebox.showwarning("No outputs", "Select at least one output coefficient on Tab 1.")
            return
        overlap = set(input_cols) & set(output_cols)
        if overlap:
            messagebox.showwarning("Overlapping columns",
                                    f"These columns are selected as BOTH input and output: {sorted(overlap)}\n"
                                    "Please fix the selection on Tab 1.")
            return

        selected_algos = [name for name, var in self.model_checks.items() if var.get()]
        if not selected_algos:
            messagebox.showwarning("No model selected", "Check at least one model to train on this tab.")
            return

        self.btn_train.config(state="disabled")
        self.btn_stop.config(state="normal")
        self.progress.start(10)
        self.stop_flag.clear()

        algo_params = {}
        algo_use_scaling = {}
        for name in selected_algos:
            optional = fc.MODEL_SUPPORTS_OPTIONAL_PARAMS.get(name, True)
            algo_params[name] = read_param_panel(self.param_varmaps[name], fc.MODEL_SPECS[name], optional=optional)
            if name in self.scaling_checks:
                algo_use_scaling[name] = self.scaling_checks[name].get()

        # Capture every Tk-variable value on the MAIN thread before handing off to
        # the worker thread — Tk variables/widgets must not be touched from a
        # background thread.
        mode = self.data_mode.get()
        single_sheet = self.single_sheet_var.get()
        input_sheet = self.input_sheet_var.get()
        output_sheet = self.output_sheet_var.get()
        plot_title = self.plot_title_train.get()
        out_dir = self.output_dir

        self.log_box.insert(tk.END, f"\n========== Run started {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ==========\n")
        self.log_box.see(tk.END)

        t = threading.Thread(
            target=self._train_worker,
            args=(input_cols, output_cols, selected_algos, algo_params, algo_use_scaling,
                  mode, single_sheet, input_sheet, output_sheet, plot_title, out_dir),
            daemon=True)
        t.start()

    def _stop_training(self):
        self.stop_flag.set()
        self._log("[INFO] Stop requested — current model will halt after its current output finishes.")
        self.btn_stop.config(state="disabled")

    def _train_worker(self, input_cols, output_cols, selected_algos, algo_params, algo_use_scaling,
                       mode, single_sheet, input_sheet, output_sheet, plot_title, out_dir):
        try:
            X, y = fc.load_dataset(
                self.training_path, mode, input_cols, output_cols,
                single_sheet=single_sheet if mode == "single" else None,
                input_sheet=input_sheet if mode == "dual" else None,
                output_sheet=output_sheet if mode == "dual" else None,
            )
            self._log(f"[INFO] Training samples: {len(X)} | Inputs: {len(input_cols)} | Outputs: {len(output_cols)}")

            from sklearn.model_selection import train_test_split
            X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, shuffle=True)
            self._log(f"[INFO] Train: {X_train.shape} Test: {X_test.shape}")

            os.makedirs(out_dir, exist_ok=True)
            results = {}

            for algo in selected_algos:
                if self.stop_flag.is_set():
                    self._log("[INFO] Training halted by user.")
                    break
                self._log(f"\n===== {algo} =====")
                params = algo_params[algo]
                t0 = time.time()
                try:
                    if algo == "DNN":
                        res = fc.train_dnn_model(X_train, y_train, X_test, y_test, params,
                                                  log_fn=self._log, stop_flag=self.stop_flag)
                    else:
                        res = fc.train_sklearn_style_model(
                            algo, X_train, y_train, X_test, y_test, params,
                            log_fn=self._log, stop_flag=self.stop_flag,
                            use_scaling=algo_use_scaling.get(algo, False))
                except Exception:
                    self._log(f"[ERROR] {algo} failed:\n" + traceback.format_exc())
                    continue
                if res is None:
                    continue
                dt = time.time() - t0
                self._log(f"[RESULT] {algo} finished in {dt:.2f}s")
                self._log("[METRICS - Test Set]\n" + res["test_metrics"].to_string(index=False))
                self._log("[METRICS - Train Set]\n" + res["train_metrics"].to_string(index=False))
                results[algo] = res

                fname_prefix = f"{algo}_Training_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
                plots = fc.generate_all_plots(res, out_dir, f"{plot_title} — {algo}", fname_prefix)
                for pname, ppath in plots.items():
                    self.msg_queue.put(("new_plot", (f"{algo} - {pname}", ppath)))

            self.msg_queue.put(("train_done", results))
        except Exception:
            self._log("[ERROR] Training pipeline failed:\n" + traceback.format_exc())
            self.msg_queue.put(("train_done", {}))

    def _regenerate_train_plots(self):
        active = self.active_model_name.get()
        if not active or active not in self.trained_models:
            messagebox.showwarning("No model", "Select an active trained model first.")
            return
        res = self.trained_models[active]
        fname_prefix = f"{active}_Training_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        plots = fc.generate_all_plots(res, self.output_dir, f"{self.plot_title_train.get()} — {active}", fname_prefix)
        first_key = None
        for pname, ppath in plots.items():
            key = f"{active} - {pname}"
            if first_key is None:
                first_key = key
            self.train_plot_viewer.add_plot(key, ppath)
        # Force the viewer to actually show the freshly regenerated image, so
        # the change is visible even if the previously-selected plot wasn't
        # one of this model's — otherwise this button looks like it did
        # nothing when its only effect (the title text) isn't obviously
        # visible from whatever was on screen before.
        if first_key:
            self.train_plot_viewer.combo_var.set(first_key)
            self.train_plot_viewer._render()
        self.lbl_regen_status.config(text=f"✓ Updated {len(plots)} plot(s) at "
                                           f"{datetime.now().strftime('%H:%M:%S')}")
        self._log(f"[INFO] Regenerated plots for {active} with title '{self.plot_title_train.get()}'")

    # ---- save / load / clear ----
    def _save_active_model(self):
        active = self.active_model_name.get()
        if not active or active not in self.trained_models:
            messagebox.showwarning("No model", "Select an active trained model first.")
            return
        res = self.trained_models[active]
        is_dnn = res["algo"] == "DNN"
        if is_dnn:
            filetypes = [("Keras model (.keras)", "*.keras"), ("All files", "*.*")]
            default_ext = ".keras"
        else:
            filetypes = [("Pickle model (.pkl)", "*.pkl"), ("All files", "*.*")]
            default_ext = ".pkl"
        base_name = filedialog.asksaveasfilename(
            title=f"Save {res['algo']} model as...",
            initialdir=self.output_dir, initialfile=f"{active}_model",
            defaultextension=default_ext, filetypes=filetypes)
        if not base_name:
            return
        base_dir = os.path.dirname(base_name) or self.output_dir
        base = os.path.splitext(os.path.basename(base_name))[0]
        paths = fc.save_model(res, base_dir, base)
        if is_dnn:
            messagebox.showinfo(
                "Saved",
                f"{res['algo']} model saved as TWO files (both are needed to load it again):\n" + "\n".join(paths))
        else:
            messagebox.showinfo("Saved", f"{res['algo']} model saved to:\n" + "\n".join(paths))

    def _load_model_dialog(self):
        path = filedialog.askopenfilename(
            title="Select model file — a .pkl for XGBoost/RandomForest/SVR/LightGBM, or a .keras for DNN",
            filetypes=[("All model files", "*.pkl *.keras"),
                       ("Sklearn/XGBoost/RandomForest/SVR/LightGBM (.pkl)", "*.pkl"),
                       ("DNN network (.keras)", "*.keras")])
        if not path:
            return
        try:
            if path.endswith(".keras"):
                scaler_path = filedialog.askopenfilename(
                    title=f"Now select the matching scalers file for {os.path.basename(path)} "
                          f"(named <same base name>_scalers.pkl)",
                    filetypes=[("Scalers file (.pkl)", "*.pkl")])
                if not scaler_path:
                    return
                model_data = fc.load_dnn_model(path, scaler_path)
            else:
                model_data = fc.load_sklearn_style_model(path)
        except Exception as e:
            messagebox.showerror("Load failed", str(e))
            return

        algo = model_data.get("algo", "Loaded")
        key = f"{algo} (loaded)"
        self.trained_models[key] = model_data
        self._refresh_model_dropdown()
        self.active_model_name.set(key)
        self._log(f"[INFO] Loaded model: {key} from {path}")
        messagebox.showinfo("Loaded", f"Model loaded as '{key}'. Go to Tab 3 to predict.")
        self._sync_predict_tab_with_model()

    def _clear_trained_models(self):
        removed = [k for k in list(self.trained_models.keys()) if not k.endswith("(loaded)")]
        for k in removed:
            del self.trained_models[k]
        self._refresh_model_dropdown()
        self._log(f"[INFO] Cleared {len(removed)} trained model(s).")

    def _clear_loaded_model(self):
        removed = [k for k in list(self.trained_models.keys()) if k.endswith("(loaded)")]
        for k in removed:
            del self.trained_models[k]
        self._refresh_model_dropdown()
        self._log(f"[INFO] Cleared {len(removed)} loaded model(s).")

    def _refresh_model_dropdown(self):
        names = list(self.trained_models.keys())
        self.active_model_combo["values"] = names
        if names and self.active_model_name.get() not in names:
            self.active_model_name.set(names[0])
        if not names:
            self.active_model_name.set("")
        self._sync_predict_tab_with_model()

    # ==================================================================
    # TAB 3 — PREDICT
    # ==================================================================
    def _build_tab_predict(self):
        self.tab_predict.rowconfigure(0, weight=1)
        self.tab_predict.columnconfigure(0, weight=1)
        outer = ScrollableFrame(self.tab_predict, height=700)
        outer.grid(row=0, column=0, sticky="nsew")
        root = outer.inner

        card_model = Card(root, title="Active Model")
        card_model.pack(fill="x", padx=10, pady=8)
        self.lbl_active_model_info = ttk.Label(card_model, text="No active model. Train or load one on Tab 2.",
                                                foreground=TEXT_MUTED, background=CARD_BG, wraplength=1100,
                                                justify="left")
        self.lbl_active_model_info.pack(anchor="w")

        mode_row = ttk.Frame(root, style="TFrame")
        mode_row.pack(fill="x", padx=10, pady=(4, 0))
        self.predict_mode = tk.StringVar(value="file")
        ttk.Radiobutton(mode_row, text="Predict from Test File", variable=self.predict_mode,
                        value="file", command=self._refresh_predict_view).pack(side="left")
        ttk.Radiobutton(mode_row, text="Manual Entry", variable=self.predict_mode,
                        value="manual", command=self._refresh_predict_view).pack(side="left", padx=15)

        self.predict_body = ttk.Frame(root, style="TFrame")
        self.predict_body.pack(fill="both", expand=True, padx=0, pady=8)

        self._build_predict_file_view()
        self._build_predict_manual_view()
        self._refresh_predict_view()

    # ---- file-based prediction ----
    def _build_predict_file_view(self):
        self.frame_predict_file = ttk.Frame(self.predict_body, style="TFrame")

        card_file = Card(self.frame_predict_file, title="Test File")
        card_file.pack(fill="x", padx=10, pady=6)
        row = ttk.Frame(card_file, style="Card.TFrame")
        row.pack(fill="x")
        ttk.Button(row, text="Browse Test File (.xlsx)", command=self._browse_test_file).pack(side="left")
        ttk.Button(row, text="Remove File", command=self._remove_test_file).pack(side="left", padx=6)
        self.lbl_test_path = ttk.Label(row, text="No file selected", foreground=TEXT_MUTED, background=CARD_BG)
        self.lbl_test_path.pack(side="left", padx=10)

        row2 = ttk.Frame(card_file, style="Card.TFrame")
        row2.pack(fill="x", pady=(8, 0))
        ttk.Label(row2, text="Sheet layout:", background=CARD_BG).pack(side="left")
        ttk.Radiobutton(row2, text="Inputs + outputs in same sheet", variable=self.test_data_mode,
                         value="single", command=self._on_test_data_mode_change).pack(side="left", padx=8)
        ttk.Radiobutton(row2, text="Inputs and outputs in different sheets", variable=self.test_data_mode,
                         value="dual", command=self._on_test_data_mode_change).pack(side="left", padx=8)

        self.test_sheet_picker_frame = ttk.Frame(card_file, style="Card.TFrame")
        self.test_sheet_picker_frame.pack(fill="x", pady=(8, 0))
        ttk.Button(card_file, text="Load Columns From File", command=self._load_test_columns).pack(anchor="w", pady=(8, 0))

        self.lbl_test_feature_status = ttk.Label(card_file, text="", background=CARD_BG)
        self.lbl_test_feature_status.pack(anchor="w", pady=(6, 0))

        card_override = Card(self.frame_predict_file, title="Override One Column (optional)")
        card_override.pack(fill="x", padx=10, pady=6)
        orow = ttk.Frame(card_override, style="Card.TFrame")
        orow.pack(fill="x")
        ttk.Checkbutton(orow, text="Enable override sweep", variable=self.override_enabled).pack(side="left")
        ttk.Label(orow, text="Column:", background=CARD_BG).pack(side="left", padx=(16, 4))
        self.override_col_combo = ttk.Combobox(orow, textvariable=self.override_col_var, width=18, state="readonly")
        self.override_col_combo.pack(side="left")
        ttk.Label(orow, text="Values (comma-separated):", background=CARD_BG).pack(side="left", padx=(16, 4))
        ttk.Entry(orow, textvariable=self.override_values_var, width=30).pack(side="left")
        ttk.Label(card_override,
                  text="When enabled, prediction ignores the file's rows and instead builds one synthetic row per\n"
                       "value you list here (every other column held at its median / most common value from the\n"
                       "test file), and predicts only those points. This mode has no ground-truth values, so you\n"
                       "get 4 plots that describe the sweep itself (not error metrics): the raw sweep curve, a bar\n"
                       "comparison, % change from your first point, and step-to-step sensitivity.",
                  foreground=TEXT_MUTED, background=CARD_BG, justify="left").pack(anchor="w", pady=(6, 0))

        run_row = ttk.Frame(self.frame_predict_file, style="TFrame")
        run_row.pack(fill="x", padx=10, pady=6)
        self.btn_run_predict = ttk.Button(run_row, text="Run Prediction", style="Accent.TButton",
                                           command=self._run_file_prediction, state="disabled")
        self.btn_run_predict.pack(side="left")

        card_results = Card(self.frame_predict_file, title="Prediction Results")
        card_results.pack(fill="both", expand=True, padx=10, pady=6)

        title_row = ttk.Frame(card_results, style="Card.TFrame")
        title_row.pack(fill="x")
        ttk.Label(title_row, text="Plot title:", background=CARD_BG).pack(side="left")
        ttk.Entry(title_row, textvariable=self.plot_title_predict, width=40).pack(side="left", padx=6)
        ttk.Button(title_row, text="Clear Log", command=lambda: self.predict_log.delete("1.0", tk.END)).pack(side="right")
        ttk.Button(title_row, text="Clear Plots", command=lambda: self.predict_plot_viewer.clear()).pack(side="right", padx=(0, 6))

        results_nb = ttk.Notebook(card_results)
        results_nb.pack(fill="both", expand=True, pady=(8, 0))

        log_tab = ttk.Frame(results_nb, style="Card.TFrame", padding=8)
        results_nb.add(log_tab, text="Log & Metrics")
        # Log and metrics live in ONE widget, as requested — metrics get appended
        # to the same scrolling log right after each prediction run finishes.
        self.predict_log = scrolledtext.ScrolledText(log_tab, height=26, font=FONT_MONO, wrap="word")
        self.predict_log.pack(fill="both", expand=True)

        plots_tab = ttk.Frame(results_nb, style="Card.TFrame", padding=8)
        results_nb.add(plots_tab, text="Plots")
        self.predict_plot_viewer = PlotViewer(plots_tab)
        self.predict_plot_viewer.pack(fill="both", expand=True)

    def _on_test_data_mode_change(self):
        for w in self.test_sheet_picker_frame.winfo_children():
            w.destroy()
        if self.test_data_mode.get() == "single":
            ttk.Label(self.test_sheet_picker_frame, text="Sheet:", background=CARD_BG).pack(side="left")
            ttk.Combobox(self.test_sheet_picker_frame, textvariable=self.test_single_sheet_var,
                         values=self.test_sheets, width=24, state="readonly").pack(side="left", padx=6)
        else:
            ttk.Label(self.test_sheet_picker_frame, text="Input sheet:", background=CARD_BG).pack(side="left")
            ttk.Combobox(self.test_sheet_picker_frame, textvariable=self.test_input_sheet_var,
                         values=self.test_sheets, width=20, state="readonly").pack(side="left", padx=6)
            ttk.Label(self.test_sheet_picker_frame, text="Output sheet:", background=CARD_BG).pack(side="left", padx=(12, 0))
            ttk.Combobox(self.test_sheet_picker_frame, textvariable=self.test_output_sheet_var,
                         values=self.test_sheets, width=20, state="readonly").pack(side="left", padx=6)

    def _browse_test_file(self):
        path = filedialog.askopenfilename(title="Select test Excel file",
                                           filetypes=[("Excel files", "*.xlsx *.xls *.xlsm")])
        if not path:
            return
        ext = os.path.splitext(path)[1].lower()
        if ext not in (".xlsx", ".xls", ".xlsm"):
            messagebox.showerror("Invalid file", "Please upload an Excel file only (.xlsx, .xls, .xlsm).")
            return
        try:
            sheets = fc.list_sheet_names(path)
        except Exception as e:
            messagebox.showerror("Error", f"Could not open workbook:\n{e}")
            return
        self.test_path = path
        self.test_sheets = sheets
        self.lbl_test_path.config(text=os.path.basename(path), foreground="black")
        if sheets:
            self.test_single_sheet_var.set(sheets[0])
            self.test_input_sheet_var.set(sheets[0])
            self.test_output_sheet_var.set(sheets[1] if len(sheets) > 1 else sheets[0])
        self._on_test_data_mode_change()
        self._update_run_predict_state()

    def _remove_test_file(self):
        self.test_path = None
        self.test_sheets = []
        self.test_df_in = None
        self.test_df_out = None
        self.lbl_test_path.config(text="No file selected", foreground=TEXT_MUTED)
        self.lbl_test_feature_status.config(text="")
        self._update_run_predict_state()

    def _load_test_columns(self):
        if not self.test_path:
            messagebox.showwarning("No file", "Choose a test file first.")
            return
        active = self._get_active_model_data()
        try:
            mode = self.test_data_mode.get()
            if mode == "single":
                df = pd.read_excel(self.test_path, sheet_name=self.test_single_sheet_var.get())
                self.test_df_in = df
                self.test_df_out = df
            else:
                self.test_df_in = pd.read_excel(self.test_path, sheet_name=self.test_input_sheet_var.get())
                self.test_df_out = pd.read_excel(self.test_path, sheet_name=self.test_output_sheet_var.get())
        except Exception as e:
            messagebox.showerror("Error", f"Could not read test file:\n{e}")
            return

        if active:
            required = set(active["input_cols"])
            missing = required - set(self.test_df_in.columns)
            if missing:
                self.lbl_test_feature_status.config(
                    text=f"Missing {len(missing)} required input columns: {sorted(missing)}",
                    foreground=BAD)
            else:
                self.lbl_test_feature_status.config(
                    text=f"All {len(required)} required input features found.", foreground=GOOD)
            self.override_col_combo["values"] = active["input_cols"]
        else:
            self.lbl_test_feature_status.config(
                text="No active model — train or load one on Tab 2 to validate required columns.",
                foreground=WARN)
        self._update_run_predict_state()

    def _get_active_model_data(self):
        name = self.active_model_name.get()
        return self.trained_models.get(name)

    def _update_run_predict_state(self):
        active = self._get_active_model_data()
        ok = active is not None and self.test_df_in is not None
        if ok:
            missing = set(active["input_cols"]) - set(self.test_df_in.columns)
            ok = not missing
        self.btn_run_predict.config(state="normal" if ok else "disabled")

    def _run_file_prediction(self):
        active = self._get_active_model_data()
        if active is None:
            messagebox.showwarning("No model", "Train or load a model first (Tab 2).")
            return
        if self.test_df_in is None:
            messagebox.showwarning("No file", "Load a test file and click 'Load Columns From File' first.")
            return

        # Capture all Tk-variable / stateful values on the MAIN thread first.
        override_enabled = self.override_enabled.get()
        override_col = self.override_col_var.get()
        override_values_raw = self.override_values_var.get()
        out_dir = self.output_dir
        plot_title = self.plot_title_predict.get()
        test_df_in = self.test_df_in
        test_df_out = self.test_df_out

        self.predict_log.insert(tk.END, f"\n========== Run started {datetime.now().strftime('%Y-%m-%d %H:%M:%S')} ==========\n")
        self.predict_log.see(tk.END)

        def log(msg):
            self.msg_queue.put(("predict_log", str(msg)))

        def worker():
            try:
                os.makedirs(out_dir, exist_ok=True)
                stamp = datetime.now().strftime("%Y%m%d_%H%M%S")

                if override_enabled:
                    if not override_col or not override_values_raw.strip():
                        log("[ERROR] Override enabled but column or values are missing.")
                        return
                    try:
                        values = [v.strip() if override_col in active["cat_cols"] else float(v.strip())
                                  for v in override_values_raw.split(",") if v.strip()]
                    except ValueError:
                        log("[ERROR] Could not parse override values as numbers.")
                        return
                    baseline = fc.build_baseline_row(active, test_df_in)
                    log(f"[INFO] Override sweep on '{override_col}' with {len(values)} point(s).")
                    log(f"[INFO] Baseline row (all other columns): {baseline}")
                    result_df, preds = fc.predict_with_override(active, baseline, override_col, values)

                    fname_prefix = f"Predict_Override_{stamp}"
                    override_plots = fc.generate_override_plots(
                        override_col, values, preds, active["output_cols"], out_dir, plot_title, fname_prefix)
                    plot_labels = {
                        "override_sweep": f"Override sweep on {override_col}",
                        "override_bar": f"Override bar comparison on {override_col}",
                        "override_pct_change": f"Override % change from first point ({override_col})",
                        "override_sensitivity": f"Override sensitivity ({override_col})",
                    }
                    for pkey, ppath in override_plots.items():
                        self.msg_queue.put(("new_predict_plot", (plot_labels.get(pkey, pkey), ppath)))

                    log(f"[DONE] {len(result_df)} override point(s) predicted. 4 plots generated (sweep, bar "
                        f"comparison, % change from your first point, and sensitivity) — none of these are "
                        f"error/accuracy metrics, since override mode has no ground truth to compare against; "
                        f"they all describe how the prediction itself moves as you sweep {override_col}.")

                else:
                    result_df, preds = fc.predict_from_dataframe(active, test_df_in, test_df_out)
                    output_cols = active["output_cols"]
                    if test_df_out is not None and all(c in test_df_out.columns for c in output_cols):
                        y_true_check = test_df_out[output_cols]
                    else:
                        y_true_check = pd.DataFrame({c: [np.nan] * len(test_df_in) for c in output_cols})
                    has_actuals = fc.has_valid_actuals(y_true_check, output_cols)

                    if has_actuals:
                        df_metrics = fc.compute_metrics_summary(y_true_check, preds, len(active["input_cols"]))
                        log("[METRICS]\n" + df_metrics.to_string(index=False))

                        fname_prefix = f"Predict_{stamp}"
                        plots = fc.generate_all_plots(
                            active, out_dir, plot_title, fname_prefix,
                            X_override=test_df_in, y_true_override=y_true_check, y_pred_override=preds,
                            include_error_plots=True)
                    else:
                        log("[INFO] Test file has no matching actual output values — showing predicted values "
                            "only, no error metrics (this is expected if your test file doesn't include the "
                            "true coefficients).")
                        fname_prefix = f"Predict_{stamp}"
                        plots = fc.generate_all_plots(
                            active, out_dir, plot_title, fname_prefix,
                            X_override=test_df_in, y_true_override=y_true_check,
                            y_pred_override=preds, include_error_plots=False)

                    for pname, ppath in plots.items():
                        self.msg_queue.put(("new_predict_plot", (pname, ppath)))

                    log(f"[DONE] {len(result_df)} row(s) predicted.")

                out_path = os.path.join(out_dir, f"Predictions_{stamp}.xlsx")
                with pd.ExcelWriter(out_path, engine="openpyxl") as writer:
                    result_df.to_excel(writer, sheet_name="Predictions", index=False)
                log(f"[DONE] Results saved to: {out_path}")
            except Exception:
                log("[ERROR] Prediction failed:\n" + traceback.format_exc())

        threading.Thread(target=worker, daemon=True).start()

    # ---- manual entry prediction ----
    def _build_predict_manual_view(self):
        self.frame_predict_manual = ttk.Frame(self.predict_body, style="TFrame")

        card_form = Card(self.frame_predict_manual, title="Manual Entry — one row at a time")
        card_form.pack(fill="x", padx=10, pady=6)
        ttk.Label(card_form, text="Values default to training median / most common category. "
                                   "Fill in what you need, then predict — the entry is added to the results "
                                   "table below so you can build up several predictions.",
                  foreground=TEXT_MUTED, background=CARD_BG, wraplength=1100, justify="left").pack(anchor="w")

        self.manual_form_scroll = ScrollableFrame(card_form, height=280)
        self.manual_form_scroll.pack(fill="both", expand=True, pady=8)

        btn_row = ttk.Frame(card_form, style="Card.TFrame")
        btn_row.pack(fill="x", pady=(6, 0))
        ttk.Button(btn_row, text="Predict This Entry", style="Accent.TButton",
                   command=self._run_manual_prediction).pack(side="left")
        ttk.Button(btn_row, text="Reset Form to Defaults", command=self._populate_manual_form).pack(side="left", padx=6)

        card_results = Card(self.frame_predict_manual, title="Batch Results")
        card_results.pack(fill="both", expand=True, padx=10, pady=6)
        rbtn_row = ttk.Frame(card_results, style="Card.TFrame")
        rbtn_row.pack(fill="x")
        ttk.Button(rbtn_row, text="Save Results (.xlsx)", command=self._save_manual_results).pack(side="left")
        ttk.Button(rbtn_row, text="Clear Results", command=self._clear_manual_results).pack(side="left", padx=6)

        # A Treeview scales to many columns (with a horizontal scrollbar) far
        # better than one giant fixed-width row per feature — this is what
        # made 100+ input features unusable before.
        tree_frame = ttk.Frame(card_results, style="Card.TFrame")
        tree_frame.pack(fill="both", expand=True, pady=(8, 0))
        self.manual_tree = ttk.Treeview(tree_frame, show="headings", height=10)
        vsb = ttk.Scrollbar(tree_frame, orient="vertical", command=self.manual_tree.yview)
        hsb = ttk.Scrollbar(tree_frame, orient="horizontal", command=self.manual_tree.xview)
        self.manual_tree.configure(yscrollcommand=vsb.set, xscrollcommand=hsb.set)
        self.manual_tree.grid(row=0, column=0, sticky="nsew")
        vsb.grid(row=0, column=1, sticky="ns")
        hsb.grid(row=1, column=0, sticky="ew")
        tree_frame.rowconfigure(0, weight=1)
        tree_frame.columnconfigure(0, weight=1)

        self.manual_entry_vars = {}
        self.manual_results = []

    def _populate_manual_form(self):
        active = self._get_active_model_data()
        for w in self.manual_form_scroll.inner.winfo_children():
            w.destroy()
        self.manual_entry_vars = {}
        if active is None:
            ttk.Label(self.manual_form_scroll.inner, text="Train or load a model first (Tab 2).",
                      foreground=BAD).grid(row=0, column=0, padx=10, pady=10)
            return

        cat_cols = set(active["cat_cols"])
        raw_categories = active.get("raw_categories", {})
        defaults = active.get("defaults", {})

        # Vertical, wrapping 3-per-row form — scales cleanly to 100+ features
        # via the scrollable frame instead of an ever-widening single row.
        for i, col in enumerate(active["input_cols"]):
            r, c = divmod(i, 3)
            cell = ttk.Frame(self.manual_form_scroll.inner)
            cell.grid(row=r, column=c, sticky="w", padx=8, pady=3)
            ttk.Label(cell, text=col, width=16, anchor="w").pack(side="left")
            if col in cat_cols:
                var = tk.StringVar(value=str(defaults.get(col, "")))
                w = ttk.Combobox(cell, textvariable=var, values=raw_categories.get(col, []), width=12)
            else:
                var = tk.StringVar(value=str(defaults.get(col, 0)))
                w = ttk.Entry(cell, textvariable=var, width=14)
            w.pack(side="left", padx=4)
            self.manual_entry_vars[col] = var

    def _run_manual_prediction(self):
        active = self._get_active_model_data()
        if active is None:
            messagebox.showwarning("No model", "Train or load a model first.")
            return
        values = {}
        for col, var in self.manual_entry_vars.items():
            raw = var.get()
            if col in active["cat_cols"]:
                values[col] = raw
            else:
                try:
                    values[col] = float(raw)
                except ValueError:
                    messagebox.showerror("Invalid value", f"'{raw}' is not a number for '{col}'.")
                    return
        try:
            preds = fc.predict_manual(active, values)
        except Exception:
            messagebox.showerror("Prediction failed", traceback.format_exc())
            return

        row = {**values, **{f"{k}_Predicted": round(float(v), 6) for k, v in preds.items()}}
        self.manual_results.append(row)
        self._refresh_manual_tree(active)

    def _refresh_manual_tree(self, active):
        cols = active["input_cols"] + [f"{c}_Predicted" for c in active["output_cols"]]
        self.manual_tree["columns"] = cols
        for c in cols:
            self.manual_tree.heading(c, text=c)
            self.manual_tree.column(c, width=100, anchor="center", stretch=False)
        self.manual_tree.delete(*self.manual_tree.get_children())
        for i, row in enumerate(self.manual_results):
            values = [row.get(c, "") for c in cols]
            self.manual_tree.insert("", "end", iid=str(i), values=values)

    def _clear_manual_results(self):
        self.manual_results = []
        self.manual_tree.delete(*self.manual_tree.get_children())

    def _save_manual_results(self):
        if not self.manual_results:
            messagebox.showwarning("No results", "Predict at least one entry first.")
            return
        path = filedialog.asksaveasfilename(defaultextension=".xlsx", initialdir=self.output_dir,
                                             filetypes=[("Excel files", "*.xlsx")])
        if not path:
            return
        pd.DataFrame(self.manual_results).to_excel(path, index=False)
        messagebox.showinfo("Saved", f"Saved to:\n{path}")

    def _refresh_predict_view(self):
        self.frame_predict_file.pack_forget()
        self.frame_predict_manual.pack_forget()
        if self.predict_mode.get() == "file":
            self.frame_predict_file.pack(fill="both", expand=True)
        else:
            self.frame_predict_manual.pack(fill="both", expand=True)
            self._populate_manual_form()

    def _sync_predict_tab_with_model(self):
        active = self._get_active_model_data()
        if active is None:
            self.lbl_active_model_info.config(text="No active model. Train or load one on Tab 2.", foreground=TEXT_MUTED)
        else:
            scaling_note = "scaled inputs/outputs" if active.get("scalers") is not None else "no scaling"
            self.lbl_active_model_info.config(
                text=f"Algorithm: {active['algo']} ({scaling_note})  |  Inputs ({len(active['input_cols'])}): "
                     f"{', '.join(active['input_cols'])}  |  Outputs: {', '.join(active['output_cols'])}",
                foreground="black")
            self.override_col_combo["values"] = active["input_cols"]
        self._update_run_predict_state()
        if hasattr(self, "manual_form_scroll") and self.predict_mode.get() == "manual":
            self._populate_manual_form()

    # ==================================================================
    # Background queue polling (keeps GUI thread-safe)
    # ==================================================================
    def _poll_queue(self):
        try:
            while True:
                kind, payload = self.msg_queue.get_nowait()
                if kind == "log":
                    self.log_box.insert(tk.END, payload + "\n")
                    self.log_box.see(tk.END)
                elif kind == "predict_log":
                    self.predict_log.insert(tk.END, payload + "\n")
                    self.predict_log.see(tk.END)
                elif kind == "new_plot":
                    name, path = payload
                    self.train_plot_viewer.add_plot(name, path)
                elif kind == "new_predict_plot":
                    name, path = payload
                    self.predict_plot_viewer.add_plot(name, path)
                elif kind == "train_done":
                    self.progress.stop()
                    self.btn_train.config(state="normal")
                    self.btn_stop.config(state="disabled")
                    results = payload or {}
                    for algo, res in results.items():
                        self.trained_models[algo] = res
                    self._refresh_model_dropdown()
                    if results:
                        summary = ", ".join(f"{a}: R2={r['metadata']['test_r2_avg']}" for a, r in results.items())
                        messagebox.showinfo("Training complete", summary)
                    else:
                        self._log("[INFO] No models finished training.")
        except queue.Empty:
            pass
        self.after(100, self._poll_queue)


if __name__ == "__main__":
    app = FlightApp()
    app.mainloop()
