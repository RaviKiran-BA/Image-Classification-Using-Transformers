"""
Physics-Informed Neural Network (PINN) for aerodynamic coefficients
=====================================================================

WHAT THIS DOES
- Fits a neural network to wind tunnel data for 6 coefficients:
    CN  = normal force coefficient
    CS  = side force coefficient (sometimes called CY)
    CA  = axial force coefficient
    CYM = yawing moment coefficient
    CRM = rolling moment coefficient
    CPM = pitching moment coefficient
- Inputs: angle of attack (alpha), sideslip angle (beta), Mach number.
  Add more inputs (control fin deflections, Reynolds number) if your
  dataset has them - see the "EXTENDING INPUTS" note below.

WHAT "PHYSICS-INFORMED" MEANS HERE
There is no PDE to embed for static force/moment coefficients (unlike
flow-field PINNs that embed Navier-Stokes). Instead, physics is added
as extra loss terms that penalize the network for violating known
symmetry properties of the aerodynamics. Two kinds are included:

  1. Plane-of-symmetry constraints (valid for almost any conventional
     body with a vertical plane of symmetry, e.g. most aircraft/missiles):
       - CN, CA, CPM are SYMMETRIC in beta:   f(alpha, -beta) =  f(alpha, beta)
       - CS, CYM, CRM are ANTISYMMETRIC in beta: f(alpha, -beta) = -f(alpha, beta)
     This also forces CS = CYM = CRM = 0 exactly at beta = 0, which is
     physically required for a symmetric body.

  2. Cross-coupling symmetry for BODIES OF REVOLUTION ONLY
     (e.g. missiles, rockets, projectiles - NOT aircraft):
       CN(alpha, beta) ~ CS(beta, alpha)
       CPM(alpha, beta) ~ CYM(beta, alpha)
     This comes from the body looking the same when you swap the roles
     of alpha and beta (roll symmetry). This is turned OFF by default
     (USE_AXISYMMETRIC_COUPLING = False) because it is WRONG for
     winged/finned-asymmetric or aircraft-type geometries. Only turn it
     on if your test article is a genuine body of revolution.

I'm flagging this as [medium confidence]: these are standard textbook
relations (see Nielsen, "Missile Aerodynamics"), but you should verify
against your own geometry and data before trusting the physics loss.

REQUIREMENTS
    pip install torch pandas numpy matplotlib --break-system-packages

INPUT DATA FORMAT (CSV)
    alpha, beta, mach, CN, CS, CA, CYM, CRM, CPM
    (angles in degrees; one row per wind tunnel test point)
"""

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import matplotlib.pyplot as plt

# ----------------------------------------------------------------------
# CONFIG - edit these for your case
# ----------------------------------------------------------------------
CSV_PATH = "wind_tunnel_data.csv"          # your data file
INPUT_COLS = ["alpha", "beta", "mach"]     # extend if you have more (see note below)
OUTPUT_COLS = ["CN", "CS", "CA", "CYM", "CRM", "CPM"]

USE_SYMMETRY_LOSS = True          # plane-of-symmetry constraint (safe default)
USE_AXISYMMETRIC_COUPLING = False # cross-coupling constraint - ONLY for bodies of revolution

PHYSICS_WEIGHT = 0.1              # relative weight of physics loss vs data loss
N_EPOCHS = 5000
LR = 1e-3
HIDDEN_LAYERS = [64, 64, 64]
DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# ----------------------------------------------------------------------
# 1. DATA LOADING AND NORMALIZATION
# ----------------------------------------------------------------------
class AeroDataset:
    """
    Loads wind tunnel CSV, splits train/val, and normalizes inputs/outputs.
    Normalizing matters a lot here: alpha/beta are in degrees (order ~10),
    Mach is order ~1, and the coefficients can be order ~0.01-1. Without
    normalization the network will effectively ignore the small-scale
    coefficients during training.
    """
    def __init__(self, csv_path, input_cols, output_cols, val_frac=0.2, seed=0):
        df = pd.read_csv(csv_path)
        missing = [c for c in input_cols + output_cols if c not in df.columns]
        if missing:
            raise ValueError(f"CSV is missing expected columns: {missing}")

        rng = np.random.default_rng(seed)
        idx = rng.permutation(len(df))
        n_val = int(len(df) * val_frac)
        val_idx, train_idx = idx[:n_val], idx[n_val:]

        X = df[input_cols].values.astype(np.float32)
        Y = df[output_cols].values.astype(np.float32)

        self.x_mean, self.x_std = X[train_idx].mean(0), X[train_idx].std(0) + 1e-8
        self.y_mean, self.y_std = Y[train_idx].mean(0), Y[train_idx].std(0) + 1e-8

        self.X_train = self._norm_x(X[train_idx])
        self.Y_train = self._norm_y(Y[train_idx])
        self.X_val = self._norm_x(X[val_idx])
        self.Y_val = self._norm_y(Y[val_idx])

        self.input_cols = input_cols
        self.output_cols = output_cols

    def _norm_x(self, X):
        return (X - self.x_mean) / self.x_std

    def _norm_y(self, Y):
        return (Y - self.y_mean) / self.y_std

    def denorm_y(self, Y):
        return Y * self.y_std + self.y_mean

    def to_tensors(self, device):
        return (
            torch.tensor(self.X_train, device=device),
            torch.tensor(self.Y_train, device=device),
            torch.tensor(self.X_val, device=device),
            torch.tensor(self.Y_val, device=device),
        )


# ----------------------------------------------------------------------
# 2. MODEL
# ----------------------------------------------------------------------
class AeroPINN(nn.Module):
    """Simple MLP: inputs -> 6 aerodynamic coefficients."""
    def __init__(self, n_in, n_out, hidden_layers):
        super().__init__()
        layers = []
        prev = n_in
        for h in hidden_layers:
            layers += [nn.Linear(prev, h), nn.Tanh()]  # Tanh: smooth, gives clean derivatives
            prev = h
        layers += [nn.Linear(prev, n_out)]
        self.net = nn.Sequential(*layers)

    def forward(self, x):
        return self.net(x)


# ----------------------------------------------------------------------
# 3. PHYSICS LOSS TERMS
# ----------------------------------------------------------------------
def make_flipped_beta_input(x, dataset):
    """
    Given normalized input x = [alpha_n, beta_n, mach_n, ...], return a copy
    with beta flipped in sign (beta -> -beta), still normalized correctly.
    """
    x_raw = x.detach().cpu().numpy() * dataset.x_std + dataset.x_mean
    beta_idx = dataset.input_cols.index("beta")
    x_raw[:, beta_idx] = -x_raw[:, beta_idx]
    x_flipped = (x_raw - dataset.x_mean) / dataset.x_std
    return torch.tensor(x_flipped, dtype=x.dtype, device=x.device)


def symmetry_loss(model, x, dataset):
    """
    Penalizes violation of plane-of-symmetry:
        CN, CA, CPM   should be even in beta:  f(a,-b) - f(a,b)  ~ 0
        CS, CYM, CRM  should be odd in beta:   f(a,-b) + f(a,b)  ~ 0
    """
    x_flip = make_flipped_beta_input(x, dataset)
    y = model(x)
    y_flip = model(x_flip)

    cols = dataset.output_cols
    loss = 0.0
    even_coeffs = ["CN", "CA", "CPM"]
    odd_coeffs = ["CS", "CYM", "CRM"]
    for name in even_coeffs:
        if name in cols:
            i = cols.index(name)
            loss = loss + torch.mean((y_flip[:, i] - y[:, i]) ** 2)
    for name in odd_coeffs:
        if name in cols:
            i = cols.index(name)
            loss = loss + torch.mean((y_flip[:, i] + y[:, i]) ** 2)
    return loss


def axisymmetric_coupling_loss(model, x, dataset):
    """
    ONLY valid for bodies of revolution. Penalizes:
        CN(alpha, beta)  vs  CS(beta, alpha)
        CPM(alpha, beta) vs  CYM(beta, alpha)
    i.e. swapping alpha and beta should swap the normal-force/side-force
    (and pitch/yaw moment) roles.
    """
    cols = dataset.output_cols
    if not all(c in cols for c in ["CN", "CS", "CPM", "CYM"]):
        return torch.tensor(0.0, device=x.device)

    x_raw = x.detach().cpu().numpy() * dataset.x_std + dataset.x_mean
    a_idx = dataset.input_cols.index("alpha")
    b_idx = dataset.input_cols.index("beta")
    x_swapped_raw = x_raw.copy()
    x_swapped_raw[:, [a_idx, b_idx]] = x_swapped_raw[:, [b_idx, a_idx]]
    x_swapped = (x_swapped_raw - dataset.x_mean) / dataset.x_std
    x_swapped = torch.tensor(x_swapped, dtype=x.dtype, device=x.device)

    y = model(x)
    y_sw = model(x_swapped)

    cn_i, cs_i = cols.index("CN"), cols.index("CS")
    cpm_i, cym_i = cols.index("CPM"), cols.index("CYM")

    loss = torch.mean((y[:, cn_i] - y_sw[:, cs_i]) ** 2)
    loss = loss + torch.mean((y[:, cpm_i] - y_sw[:, cym_i]) ** 2)
    return loss


# ----------------------------------------------------------------------
# 4. TRAINING LOOP
# ----------------------------------------------------------------------
def train():
    dataset = AeroDataset(CSV_PATH, INPUT_COLS, OUTPUT_COLS)
    X_train, Y_train, X_val, Y_val = dataset.to_tensors(DEVICE)

    model = AeroPINN(len(INPUT_COLS), len(OUTPUT_COLS), HIDDEN_LAYERS).to(DEVICE)
    optimizer = torch.optim.Adam(model.parameters(), lr=LR)
    scheduler = torch.optim.lr_scheduler.CosineAnnealingLR(optimizer, T_max=N_EPOCHS)

    history = {"data_loss": [], "physics_loss": [], "val_loss": []}

    for epoch in range(N_EPOCHS):
        model.train()
        optimizer.zero_grad()

        pred = model(X_train)
        data_loss = torch.mean((pred - Y_train) ** 2)

        physics_loss = torch.tensor(0.0, device=DEVICE)
        if USE_SYMMETRY_LOSS:
            physics_loss = physics_loss + symmetry_loss(model, X_train, dataset)
        if USE_AXISYMMETRIC_COUPLING:
            physics_loss = physics_loss + axisymmetric_coupling_loss(model, X_train, dataset)

        loss = data_loss + PHYSICS_WEIGHT * physics_loss
        loss.backward()
        optimizer.step()
        scheduler.step()

        if epoch % 200 == 0 or epoch == N_EPOCHS - 1:
            model.eval()
            with torch.no_grad():
                val_pred = model(X_val)
                val_loss = torch.mean((val_pred - Y_val) ** 2).item()
            history["data_loss"].append(data_loss.item())
            history["physics_loss"].append(physics_loss.item())
            history["val_loss"].append(val_loss)
            print(f"epoch {epoch:5d} | data_loss {data_loss.item():.5f} "
                  f"| physics_loss {physics_loss.item():.5f} | val_loss {val_loss:.5f}")

    return model, dataset, history


# ----------------------------------------------------------------------
# 5. EVALUATION HELPERS
# ----------------------------------------------------------------------
def predict(model, dataset, alpha, beta, mach):
    """
    Predict all 6 coefficients for given alpha/beta/mach arrays (degrees, degrees, Mach).
    Returns a dict of coefficient_name -> numpy array.
    """
    X = np.stack([alpha, beta, mach], axis=1).astype(np.float32)
    X_n = (X - dataset.x_mean) / dataset.x_std
    model.eval()
    with torch.no_grad():
        Y_n = model(torch.tensor(X_n, device=DEVICE)).cpu().numpy()
    Y = dataset.denorm_y(Y_n)
    return {name: Y[:, i] for i, name in enumerate(dataset.output_cols)}


def plot_coefficient_vs_alpha(model, dataset, coeff_name, beta_fixed=0.0, mach_fixed=0.8):
    alpha_range = np.linspace(-10, 20, 100)
    beta_arr = np.full_like(alpha_range, beta_fixed)
    mach_arr = np.full_like(alpha_range, mach_fixed)
    preds = predict(model, dataset, alpha_range, beta_arr, mach_arr)

    plt.figure(figsize=(6, 4))
    plt.plot(alpha_range, preds[coeff_name])
    plt.xlabel("Alpha (deg)")
    plt.ylabel(coeff_name)
    plt.title(f"{coeff_name} vs Alpha (beta={beta_fixed}, Mach={mach_fixed})")
    plt.grid(True)
    plt.tight_layout()
    plt.savefig(f"{coeff_name}_vs_alpha.png", dpi=150)
    plt.close()


if __name__ == "__main__":
    model, dataset, history = train()
    torch.save(model.state_dict(), "aero_pinn_model.pt")
    for coeff in OUTPUT_COLS:
        plot_coefficient_vs_alpha(model, dataset, coeff)
    print("Done. Model saved to aero_pinn_model.pt, plots saved as PNGs.")
